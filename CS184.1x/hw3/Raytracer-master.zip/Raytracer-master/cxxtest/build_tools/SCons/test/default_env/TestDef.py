
expect_success = True
type           = 'scons'
links = {
        'cxxtest': '../../../../',
        'src'    : '../../../../test/'
        }


