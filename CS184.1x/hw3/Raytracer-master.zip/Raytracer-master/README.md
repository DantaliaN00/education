Raytracer
=========

C++ raytracer originally coded as a CS184 project