
const float maxT = 9999999;
SceneObject getClosestObject(Ray ray, float * t, SceneProperties scene);
