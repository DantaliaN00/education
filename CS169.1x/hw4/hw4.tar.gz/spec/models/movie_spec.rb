require 'spec_helper'

describe Movie do
  it "should find some movies with same director" do
    
  end
end
